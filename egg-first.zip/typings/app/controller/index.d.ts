// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCrmUser = require('../../../app/controller/crm/user');
import ExportRoadOrders = require('../../../app/controller/road/orders');
import ExportRoadUser = require('../../../app/controller/road/user');

declare module 'egg' {
  interface IController {
    crm: {
      user: ExportCrmUser;
    }
    road: {
      orders: ExportRoadOrders;
      user: ExportRoadUser;
    }
  }
}
